// FullAuto15 — ショートカットの「個人用オートメーション」を完全自動化する tweak
// iPhone 7 / iOS 15 (rootless / Dopamine) 専用に設計。
//
// 仕組み:
//  iOS 15 では「メール」「メッセージ」などのトリガーは Apple の仕様で
//  「自動で実行できるトリガー」のリストから外されていて、
//  オートメーション作成画面でも「実行前に尋ねる」を切るスイッチ自体が出ない。
//  判定は WorkflowKit の各トリガークラスが持つ
//    + (BOOL)isAllowedToRunAutomatically
//  が返している。ベースクラス WFTrigger だけでなく、iOS 13.3 以降は
//  トリガーごとのサブクラス (メール用・メッセージ用など) が個別に持つ
//  ことが分かっている (Truecuts の Issue #1)。
//
//  そのためこの tweak は:
//   1. 起動時に WFTrigger の全サブクラスを列挙し、
//   2. isAllowedToRunAutomatically を「直接」実装しているクラスを全部見つけて、
//   3. その実装を「設定が ON のときは YES を返す」実装に差し替える。
//  クラス名を決め打ちしないので、メール以外のトリガーにも効く。
//
//  差し替えは元実装を保存し、設定 OFF のときは元の答えをそのまま返す。

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

static NSString * const kPrefsID = @"app.hane.fullauto15";

static BOOL FullAutoEnabled(void) {
    Boolean exists = NO;
    Boolean value = CFPreferencesGetAppBooleanValue(CFSTR("Enabled"),
                                                     (CFStringRef)kPrefsID,
                                                     &exists);
    if (!exists) return YES; // 既定は ON
    return value;
}

// 差し替え前の元実装を覚えておく表 (キー: "クラス名+class" / "クラス名+instance")
static NSMutableDictionary<NSString *, NSValue *> *gOriginalIMPs;

static BOOL FullAuto_ClassIsAllowed(id self, SEL _cmd) {
    if (FullAutoEnabled()) return YES;
    NSString *key = [NSString stringWithFormat:@"%@+class", NSStringFromClass((Class)self)];
    NSValue *boxed = gOriginalIMPs[key];
    if (boxed) {
        BOOL (*orig)(id, SEL) = (BOOL (*)(id, SEL))[boxed pointerValue];
        return orig(self, _cmd);
    }
    return YES;
}

static BOOL FullAuto_InstanceIsAllowed(id self, SEL _cmd) {
    if (FullAutoEnabled()) return YES;
    NSString *key = [NSString stringWithFormat:@"%@+instance", NSStringFromClass([self class])];
    NSValue *boxed = gOriginalIMPs[key];
    if (boxed) {
        BOOL (*orig)(id, SEL) = (BOOL (*)(id, SEL))[boxed pointerValue];
        return orig(self, _cmd);
    }
    return YES;
}

// そのクラスが selector を「直接」実装しているか (継承しただけのものは除く)
static BOOL FullAuto_DirectlyImplements(Class cls, SEL sel, BOOL isClassMethod) {
    Class target = isClassMethod ? object_getClass(cls) : cls;
    unsigned int count = 0;
    Method *methods = class_copyMethodList(target, &count);
    BOOL found = NO;
    for (unsigned int i = 0; i < count; i++) {
        if (method_getName(methods[i]) == sel) { found = YES; break; }
    }
    if (methods) free(methods);
    return found;
}

static BOOL FullAuto_IsSubclassOf(Class cls, Class base) {
    for (Class c = cls; c; c = class_getSuperclass(c)) {
        if (c == base) return YES;
    }
    return NO;
}

static NSMutableSet<NSString *> *gSwizzledKeys;

static void FullAuto_SwizzleTriggerClasses(void) {
    Class base = objc_getClass("WFTrigger");
    if (!base) return; // WorkflowKit がまだ読み込まれていない

    SEL sel = @selector(isAllowedToRunAutomatically);
    int numClasses = objc_getClassList(NULL, 0);
    if (numClasses <= 0) return;
    Class *classes = (Class *)malloc(sizeof(Class) * numClasses);
    if (!classes) return;
    numClasses = objc_getClassList(classes, numClasses);

    for (int i = 0; i < numClasses; i++) {
        Class cls = classes[i];
        if (!FullAuto_IsSubclassOf(cls, base)) continue;

        // クラスメソッド側
        if (FullAuto_DirectlyImplements(cls, sel, YES)) {
            NSString *key = [NSString stringWithFormat:@"%@+class", NSStringFromClass(cls)];
            if (![gSwizzledKeys containsObject:key]) {
                Method m = class_getClassMethod(cls, sel);
                if (m) {
                    IMP orig = method_getImplementation(m);
                    gOriginalIMPs[key] = [NSValue valueWithPointer:(void *)orig];
                    method_setImplementation(m, (IMP)FullAuto_ClassIsAllowed);
                    [gSwizzledKeys addObject:key];
                }
            }
        }
        // インスタンスメソッド側 (存在するクラスだけ)
        if (FullAuto_DirectlyImplements(cls, sel, NO)) {
            NSString *key = [NSString stringWithFormat:@"%@+instance", NSStringFromClass(cls)];
            if (![gSwizzledKeys containsObject:key]) {
                Method m = class_getInstanceMethod(cls, sel);
                if (m) {
                    IMP orig = method_getImplementation(m);
                    gOriginalIMPs[key] = [NSValue valueWithPointer:(void *)orig];
                    method_setImplementation(m, (IMP)FullAuto_InstanceIsAllowed);
                    [gSwizzledKeys addObject:key];
                }
            }
        }
    }
    free(classes);
}

%ctor {
    @autoreleasepool {
        gOriginalIMPs = [NSMutableDictionary dictionary];
        gSwizzledKeys = [NSMutableSet set];

        FullAuto_SwizzleTriggerClasses();

        // WorkflowKit の読み込みが遅いプロセス向けに数回だけ再挑戦する
        for (NSNumber *delay in @[@1, @3, @8]) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)([delay doubleValue] * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                FullAuto_SwizzleTriggerClasses();
            });
        }
    }
}
