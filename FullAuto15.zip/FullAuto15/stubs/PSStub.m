// リンク専用のダミー。実行時は install_name の指す本物の
// Preferences.framework が使われ、このファイル自体は .deb に入らない。
// PSListController のクラス記号と _specifiers の ivar 記号だけが必要。
#import <Foundation/Foundation.h>

@interface PSListController : NSObject {
    @public
    id _specifiers;
}
@end

@implementation PSListController
@end
